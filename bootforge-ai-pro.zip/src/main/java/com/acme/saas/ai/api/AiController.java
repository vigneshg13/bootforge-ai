package com.acme.saas.ai.api;

import com.acme.saas.ai.domain.KnowledgeDocument;
import com.acme.saas.ai.service.RagChatService;
import com.acme.saas.tenant.domain.Role;
import com.acme.saas.tenant.security.RequiresRole;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/api/v1/ai")
public class AiController {

    public record IngestRequest(@NotBlank String title, @NotBlank String content) {}
    public record ChatRequest(@NotBlank String question) {}

    private final RagChatService ragChatService;

    public AiController(RagChatService ragChatService) {
        this.ragChatService = ragChatService;
    }

    @PostMapping("/documents")
    @RequiresRole(Role.ADMIN)
    public KnowledgeDocument ingestDocument(@Valid @RequestBody IngestRequest req) {
        return ragChatService.ingestText(req.title(), req.content());
    }

    @PostMapping(value = "/chat/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    @RequiresRole(Role.MEMBER)
    public Flux<String> chatStream(@Valid @RequestBody ChatRequest req) {
        return ragChatService.streamTenantChat(req.question());
    }
}
