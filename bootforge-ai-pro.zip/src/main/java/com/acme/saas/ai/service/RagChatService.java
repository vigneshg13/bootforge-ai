package com.acme.saas.ai.service;

import com.acme.saas.ai.domain.KnowledgeDocument;
import com.acme.saas.ai.domain.KnowledgeDocumentRepository;
import com.acme.saas.tenant.context.TenantContext;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.document.Document;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class RagChatService {

    private final ChatClient chatClient;
    private final VectorStore vectorStore;
    private final KnowledgeDocumentRepository documentRepository;
    private final TenantTokenGuardService tokenGuard;

    public RagChatService(ChatClient.Builder chatClientBuilder,
                          VectorStore vectorStore,
                          KnowledgeDocumentRepository documentRepository,
                          TenantTokenGuardService tokenGuard) {
        this.chatClient = chatClientBuilder.build();
        this.vectorStore = vectorStore;
        this.documentRepository = documentRepository;
        this.tokenGuard = tokenGuard;
    }

    @Transactional
    public KnowledgeDocument ingestText(String title, String content) {
        TenantContext.TenantInfo tenant = TenantContext.get();
        UUID orgId = tenant.organizationId();

        Document rawDoc = new Document(content, Map.of(
                "organizationId", orgId.toString(),
                "title", title
        ));

        List<Document> chunks = new TokenTextSplitter().apply(List.of(rawDoc));
        vectorStore.add(chunks);

        KnowledgeDocument meta = new KnowledgeDocument();
        meta.setOrganizationId(orgId);
        meta.setTitle(title);
        meta.setChunkCount(chunks.size());
        meta.setUploadedBy(tenant.userId());
        return documentRepository.save(meta);
    }

    public Flux<String> streamTenantChat(String question) {
        UUID orgId = TenantContext.requireOrgId();
        tokenGuard.checkAndReserveTokens(orgId, Math.max(500, question.length() * 2L));

        // Strict tenant metadata filter prevents cross-tenant vector retrieval
        SearchRequest searchRequest = SearchRequest.builder()
                .query(question)
                .topK(4)
                .filterExpression("organizationId == '" + orgId + "'")
                .build();

        List<Document> relevantDocs = vectorStore.similaritySearch(searchRequest);
        String context = relevantDocs.stream()
                .map(Document::getText)
                .collect(Collectors.joining("\n---\n"));

        String systemPrompt = """
                You are a helpful enterprise assistant. Answer the user's question strictly using the provided context.
                If the answer is not in the context, say you don't have enough information.
                
                Context:
                %s
                """.formatted(context);

        return chatClient.prompt()
                .system(systemPrompt)
                .user(question)
                .stream()
                .content();
    }
}
