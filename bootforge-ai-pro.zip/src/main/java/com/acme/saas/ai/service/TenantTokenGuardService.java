package com.acme.saas.ai.service;

import com.acme.saas.common.exception.BusinessException;
import com.acme.saas.tenant.domain.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDate;
import java.util.UUID;

@Service
public class TenantTokenGuardService {

    private final StringRedisTemplate redisTemplate;
    private final OrganizationRepository organizationRepository;
    private final long freeDailyLimit;
    private final long proDailyLimit;

    public TenantTokenGuardService(StringRedisTemplate redisTemplate,
                                   OrganizationRepository organizationRepository,
                                   @Value("${app.ai.free-tier-daily-tokens}") long freeDailyLimit,
                                   @Value("${app.ai.pro-tier-daily-tokens}") long proDailyLimit) {
        this.redisTemplate = redisTemplate;
        this.organizationRepository = organizationRepository;
        this.freeDailyLimit = freeDailyLimit;
        this.proDailyLimit = proDailyLimit;
    }

    public void checkAndReserveTokens(UUID orgId, long estimatedTokens) {
        Organization org = organizationRepository.findById(orgId)
                .orElseThrow(() -> new BusinessException(HttpStatus.NOT_FOUND, "ORG_NOT_FOUND", "Workspace not found"));

        long limit = (org.getPlanTier() == PlanTier.FREE) ? freeDailyLimit : proDailyLimit;
        String key = "ai:tokens:" + orgId + ":" + LocalDate.now();

        Long current = redisTemplate.opsForValue().increment(key, estimatedTokens);
        if (current != null && current == estimatedTokens) {
            redisTemplate.expire(key, Duration.ofHours(25));
        }

        if (current != null && current > limit) {
            throw new BusinessException(HttpStatus.TOO_MANY_REQUESTS, "AI_QUOTA_EXCEEDED",
                    "Daily AI token quota exceeded. Upgrade to PRO for higher limits.");
        }
    }
}
