package com.acme.saas.tenant.context;

import com.acme.saas.auth.security.UserPrincipal;
import com.acme.saas.tenant.domain.Membership;
import com.acme.saas.tenant.domain.MembershipRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.UUID;

@Component
public class TenantFilter extends OncePerRequestFilter {

    private final MembershipRepository membershipRepository;

    public TenantFilter(MembershipRepository membershipRepository) {
        this.membershipRepository = membershipRepository;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        try {
            String tenantHeader = request.getHeader("X-Tenant-Id");
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();

            if (tenantHeader != null && !tenantHeader.isBlank() && auth != null
                    && auth.getPrincipal() instanceof UserPrincipal principal) {
                UUID orgId = UUID.fromString(tenantHeader);
                Membership membership = membershipRepository
                        .findByOrganizationIdAndUserId(orgId, principal.userId())
                        .orElse(null);

                if (membership != null) {
                    TenantContext.set(new TenantContext.TenantInfo(orgId, principal.userId(), membership.getRole()));
                } else {
                    response.sendError(HttpServletResponse.SC_FORBIDDEN, "Not a member of this workspace");
                    return;
                }
            }
            chain.doFilter(request, response);
        } finally {
            TenantContext.clear();
        }
    }
}
