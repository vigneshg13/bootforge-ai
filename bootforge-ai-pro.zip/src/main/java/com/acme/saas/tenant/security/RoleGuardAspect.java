package com.acme.saas.tenant.security;

import com.acme.saas.tenant.context.TenantContext;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class RoleGuardAspect {

    @Before("@annotation(requiresRole)")
    public void checkRole(RequiresRole requiresRole) {
        TenantContext.TenantInfo info = TenantContext.get();
        if (info == null) {
            throw new AccessDeniedException("Tenant context is required for this operation");
        }
        if (!info.role().hasAtLeast(requiresRole.value())) {
            throw new AccessDeniedException("Requires role: " + requiresRole.value());
        }
    }
}
