package com.acme.saas.tenant.security;

import com.acme.saas.tenant.domain.Role;
import java.lang.annotation.*;

@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface RequiresRole {
    Role value();
}
