package com.acme.saas.billing.service;

import com.acme.saas.billing.domain.WebhookEventLog;
import com.acme.saas.billing.domain.WebhookEventLogRepository;
import com.acme.saas.common.exception.BusinessException;
import com.acme.saas.tenant.domain.*;
import com.stripe.Stripe;
import com.stripe.model.Customer;
import com.stripe.model.Event;
import com.stripe.model.Subscription;
import com.stripe.model.checkout.Session;
import com.stripe.net.Webhook;
import com.stripe.param.CustomerCreateParams;
import com.stripe.param.checkout.SessionCreateParams;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.UUID;

@Service
public class BillingService {

    private final OrganizationRepository organizationRepository;
    private final WebhookEventLogRepository webhookLogRepository;
    private final String stripeApiKey;
    private final String webhookSecret;
    private final String proPriceId;
    private final String frontendUrl;

    public BillingService(OrganizationRepository organizationRepository,
                          WebhookEventLogRepository webhookLogRepository,
                          @Value("${app.stripe.api-key}") String stripeApiKey,
                          @Value("${app.stripe.webhook-secret}") String webhookSecret,
                          @Value("${app.stripe.pro-price-id}") String proPriceId,
                          @Value("${app.frontend-url}") String frontendUrl) {
        this.organizationRepository = organizationRepository;
        this.webhookLogRepository = webhookLogRepository;
        this.stripeApiKey = stripeApiKey;
        this.webhookSecret = webhookSecret;
        this.proPriceId = proPriceId;
        this.frontendUrl = frontendUrl;
    }

    @PostConstruct
    public void init() {
        Stripe.apiKey = stripeApiKey;
    }

    @Transactional
    public String createCheckoutSession(UUID orgId) throws Exception {
        Organization org = organizationRepository.findById(orgId)
                .orElseThrow(() -> new BusinessException(HttpStatus.NOT_FOUND, "ORG_NOT_FOUND", "Workspace not found"));

        if (org.getStripeCustomerId() == null) {
            Customer customer = Customer.create(CustomerCreateParams.builder()
                    .setName(org.getName())
                    .putMetadata("organizationId", org.getId().toString())
                    .build());
            org.setStripeCustomerId(customer.getId());
            organizationRepository.save(org);
        }

        SessionCreateParams params = SessionCreateParams.builder()
                .setMode(SessionCreateParams.Mode.SUBSCRIPTION)
                .setCustomer(org.getStripeCustomerId())
                .setSuccessUrl(frontendUrl + "/billing?success=true")
                .setCancelUrl(frontendUrl + "/billing?canceled=true")
                .putMetadata("organizationId", org.getId().toString())
                .addLineItem(SessionCreateParams.LineItem.builder()
                        .setQuantity(1L)
                        .setPrice(proPriceId)
                        .build())
                .build();

        return Session.create(params).getUrl();
    }

    @Transactional
    public void handleStripeWebhook(String payload, String sigHeader) {
        Event event;
        try {
            event = Webhook.constructEvent(payload, sigHeader, webhookSecret);
        } catch (Exception e) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "INVALID_SIGNATURE", "Invalid Stripe signature");
        }

        // Idempotency guard: ignore duplicate webhook deliveries
        if (webhookLogRepository.existsById(event.getId())) {
            return;
        }

        switch (event.getType()) {
            case "checkout.session.completed" -> {
                Session session = (Session) event.getDataObjectDeserializer().getObject().orElseThrow();
                organizationRepository.findByStripeCustomerId(session.getCustomer()).ifPresent(org -> {
                    org.setPlanTier(PlanTier.PRO);
                    org.setStripeSubscriptionId(session.getSubscription());
                    org.setSubscriptionStatus("ACTIVE");
                    org.setUpdatedAt(Instant.now());
                    organizationRepository.save(org);
                });
            }
            case "customer.subscription.deleted" -> {
                Subscription sub = (Subscription) event.getDataObjectDeserializer().getObject().orElseThrow();
                organizationRepository.findByStripeCustomerId(sub.getCustomer()).ifPresent(org -> {
                    org.setPlanTier(PlanTier.FREE);
                    org.setSubscriptionStatus("CANCELED");
                    org.setUpdatedAt(Instant.now());
                    organizationRepository.save(org);
                });
            }
            default -> { /* Ignore unhandled event types */ }
        }

        webhookLogRepository.save(new WebhookEventLog(event.getId(), event.getType()));
    }
}
