package com.acme.saas.billing.api;

import com.acme.saas.billing.service.BillingService;
import com.acme.saas.tenant.context.TenantContext;
import com.acme.saas.tenant.domain.Role;
import com.acme.saas.tenant.security.RequiresRole;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/v1")
public class BillingController {

    private final BillingService billingService;

    public BillingController(BillingService billingService) {
        this.billingService = billingService;
    }

    @PostMapping("/billing/checkout")
    @RequiresRole(Role.OWNER)
    public Map<String, String> createCheckout() throws Exception {
        String url = billingService.createCheckoutSession(TenantContext.requireOrgId());
        return Map.of("checkoutUrl", url);
    }

    @PostMapping("/webhooks/stripe")
    public void stripeWebhook(@RequestBody String payload,
                              @RequestHeader("Stripe-Signature") String sigHeader) {
        billingService.handleStripeWebhook(payload, sigHeader);
    }
}
