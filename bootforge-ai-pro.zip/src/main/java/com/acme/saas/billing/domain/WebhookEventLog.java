package com.acme.saas.billing.domain;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "webhook_event_logs")
public class WebhookEventLog {
    @Id
    @Column(name = "event_id")
    private String eventId;

    @Column(name = "event_type", nullable = false)
    private String eventType;

    @Column(name = "processed_at", nullable = false)
    private Instant processedAt = Instant.now();

    protected WebhookEventLog() {}

    public WebhookEventLog(String eventId, String eventType) {
        this.eventId = eventId;
        this.eventType = eventType;
    }
}
