package com.acme.saas;

import com.acme.saas.auth.service.AuthService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.test.web.servlet.MockMvc;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@Testcontainers
class TenantIsolationIntegrationTest {

    @Container
    @ServiceConnection
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>(
            DockerImageName.parse("pgvector/pgvector:pg17").asCompatibleSubstituteFor("postgres"));

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private AuthService authService;

    @Test
    void shouldBlockAccessWhenUserQueriesAnotherTenantsWorkspace() throws Exception {
        var tenantA = authService.register("alice@acme.com", "Password123!", "Alice", "Acme Corp");
        var tenantB = authService.register("bob@rival.com", "Password123!", "Bob", "Rival Inc");

        // Bob attempts to call Stripe checkout using Alice's X-Tenant-Id header
        mockMvc.perform(post("/api/v1/billing/checkout")
                        .header("Authorization", "Bearer " + tenantB.accessToken())
                        .header("X-Tenant-Id", tenantA.defaultOrganizationId().toString()))
                .andExpect(status().isForbidden());
    }
}
