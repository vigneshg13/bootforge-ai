# ⚡ Enterprise Spring Boot + AI SaaS Starter Kit

**Ship your B2B SaaS on Java 21 & Spring Boot 4 in days—not months.**

Stop spending 60+ hours wiring multi-tenancy, RBAC, Stripe webhooks, and Spring AI RAG pipelines from scratch. Clone a clean, modular monolith engineered for high throughput and production readiness.

[![Java 21](https://img.shields.io/badge/Java-21%20(Virtual%20Threads)-orange.svg)](https://openjdk.org/)
[![Spring Boot 4](https://img.shields.io/badge/Spring%20Boot-4.1-brightgreen.svg)](https://spring.io/projects/spring-boot)
[![Spring AI](https://img.shields.io/badge/Spring%20AI-RAG%20%2B%20pgvector-blue.svg)](https://spring.io/projects/spring-ai)

---

## 🚀 Quickstart (Running Locally in 3 Minutes)

### Prerequisites
- **Java 21+**
- **Docker & Docker Compose**
- **Maven 3.9+** (or generate wrapper via `mvn wrapper:wrapper`)

### 1. Configure Environment
```bash
cp .env.example .env
```

### 2. Start Infrastructure (PostgreSQL + pgvector, Redis, Mailpit)
```bash
docker compose -f docker/docker-compose.yml up -d
```

### 3. Run the Application
```bash
mvn spring-boot:run
```

Once started, explore the local services:
- **Local Email Sandbox (Mailpit):** `http://localhost:8025`
- **Health & Actuator Metrics:** `http://localhost:8080/actuator/health`

---

## 🏗️ Architecture Highlights

- **Modular Monolith Design:** Isolated domain modules (`auth`, `tenant`, `billing`, `ai`) with clean boundaries.
- **Java 21 Virtual Threads:** Enabled globally (`spring.threads.virtual.enabled=true`) for high-concurrency database and LLM API calls.
- **Zero-Leak Multi-Tenancy:** Every tenant-scoped request is validated via `TenantFilter` and `TenantContext` plus `@RequiresRole` RBAC guards.
- **Idempotent Billing Engine:** Webhook events are logged and deduplicated in `webhook_event_logs` before processing so duplicate Stripe retries never corrupt state.
- **Production RAG + Cost Guardrails:** Built-in `TokenTextSplitter` document chunking, `pgvector` similarity search filtered by `organizationId`, Server-Sent Events (SSE) streaming, and Redis-backed per-tenant daily token quotas.

---

## 🧪 Running Tests

The test suite uses **Testcontainers** to spin up a real PostgreSQL (`pgvector`) instance automatically:

```bash
mvn test
```
